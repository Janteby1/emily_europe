  $(document).ready(function(){
  	console.log("Hello")

    $('.slider').slider({full_width: true});
    });
        